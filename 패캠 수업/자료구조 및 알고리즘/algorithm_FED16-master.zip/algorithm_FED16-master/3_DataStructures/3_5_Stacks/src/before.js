class Stack {
    constructor(capacity) {
        this.capacity = capacity
        this.top = 0;
        this.array = new Array(capacity);
    }

    push(value) {

    }

    pop() {

    }

    peek() {

    }

    isEmpty() {

    }
}