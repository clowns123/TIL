class Node {
    constructor(value, left, right) {
        this.value = value;
        this.left = left;
        this.right = right;
    }
}

class BinaryTree {
    constructor(array) {
        this.root = new Node(array[0], null, null);
        // TODO: complete tree
    }

    preorder() {

    }

    inorder() {

    }

    postorder() {

    }

    bfs(value) {

        return false;
    }

    dfs(value) {

        return false;
    }
}