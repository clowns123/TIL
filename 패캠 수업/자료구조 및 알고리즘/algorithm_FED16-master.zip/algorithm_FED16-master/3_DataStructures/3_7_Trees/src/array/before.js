class BinaryTree {
    constructor(array) {
        this.array = array;
    }

    preorder() {

    }

    inorder() {

    }

    postorder() {

    }

    bfs(value) {

        return false;
    }

    dfs(value) {

        return false;
    }

}