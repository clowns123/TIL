class LinearQueue {
    constructor(capacity) {
        this.capacity = capacity;
        this.front = 0;
        this.rear = 0;
        this.array = new Array(capacity);
    }

    put(value) {
        
    }

    get() {
        
    }

    peek() {
        
    }

    print() {

    }
}
