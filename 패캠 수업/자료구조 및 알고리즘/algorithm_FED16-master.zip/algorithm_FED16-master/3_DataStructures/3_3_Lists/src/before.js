class ArrayList {
    constructor(capacity) {
        this.capacity = capacity;
        this.array = new Int32Array(capacity);
        this.length = 0;
    }
    
    isEmpty() {

    }

    prepend(value) {

    }

    append(value) {

    }

    setHead(index) {

    }

    access(index) {

    }

    insert(index, value) {

    }

    remove(index) {

    }

    print() {
        
    }
}

