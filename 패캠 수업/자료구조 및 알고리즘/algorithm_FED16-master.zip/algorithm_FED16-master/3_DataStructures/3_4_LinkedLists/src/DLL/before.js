class Node {
    constructor(value, prev, next) {
        this.value = value;
        this.prev = prev;
        this.next = next;
    }
}

class DoublyLinkedList {
    constructor() {
        this.head = null;
    }
    
    isEmpty() {

    }

    prepend(value) {

    }

    append(value) {

    }

    setHead(index) {

    }

    access(index) {

    }

    insert(index, value) {

    }

    remove(index) {

    }

    print() {
        
    }
}
