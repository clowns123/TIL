class Node {
    constructor(value, next) {
        this.value = value;
        this.next = next;
    }
}

class SinglyLinkedList {
    constructor() {
        this.head = null;
    }
    
    isEmpty() {

    }

    prepend(value) {

    }

    append(value) {

    }

    setHead(index) {

    }

    access(index) {

    }

    insert(index, value) {

    }

    remove(index) {

    }

    print() {

    }
}
