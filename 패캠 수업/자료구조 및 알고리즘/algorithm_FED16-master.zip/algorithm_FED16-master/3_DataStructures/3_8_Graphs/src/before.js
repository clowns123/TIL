class Vertex {
    constructor(value, adjList=new Array()) {
        this.value = value;
        this.adjList = adjList;
    }
}

class Graph {
    constructor() {
        this.vertices = new Array();
    }

    insert(value, adjList) {
    }

    bfs(vertexInd) {
    }

    dfs(vertexInd) {
    }
}