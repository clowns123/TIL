# Basics

## 입출력 처리

- 코딩테스트에서 필요한 입/출력 방식을 알아본다.

## 알고리즘 구현/테스트

- Node.js를 이용해 알고리즘을 구현/테스트하는 방법을 알아본다.
- 대표적인 IDE를 알아보고, 본인에게 맞는 것을 선택한다.

## JavaScript

- 자주 사용되는 JavaScript 문법을 Review한다.
- JavaScript로 프로그래밍할 때, 좋은 습관/나쁜 습관들을 알아본다.
- JavaScript Reference를 활용하는 방법을 이해한다.
