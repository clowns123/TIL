# Homework #1

## Programmers Level1 획득

![프로그래머스 스킬체크](img/1.png)

<https://programmers.co.kr/skill_checks>

## Level1 획득 요령

- [JavaScript 레퍼런스](https://devdocs.programmers.co.kr/javascript/)를 참조하여 문제 해결
- [알고리즘 테스트용 소스](http://github.com/ai-creatv/algorithm/tree/master/2_Basics/2_2_AlgorithmTest/src/function/main.js)를 활용하여 알고리즘 테스트

## 제출 사항

- **Skill Check 레벨1 획득 스크린샷**
- **알고리즘 테스트 과정에 작성한 소스코드**
  - **main.js 및 테스트 입력 txt 파일들**

## 제출 기한 및 방법

- <ai@creatv.kr>으로 하나의 파일로 압축하여 제출
- **7월 26일(일) 자정**까지 제출
